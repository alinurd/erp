<input type="hidden" id="contact_id_for_login" value="{{$contact->id}}">
<li>
   <a href="#login" data-toggle="tab" aria-expanded="true">
       <i class="fas fa-user-plus"></i>
       @lang('crm::lang.contact_persons')
   </a> 
</li>