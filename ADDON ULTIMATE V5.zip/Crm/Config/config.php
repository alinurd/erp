<?php

return [
    'name' => 'Crm',
    'module_version' => '2.2',
    'pid' => 7,
];
