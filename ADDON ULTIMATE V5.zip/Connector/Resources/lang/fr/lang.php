<?php

return [
    'connector_module' => 'Module de connecteur',
    'connector' => 'Connecteur',
    'create_client' => 'Créer un client',
    'client_secret' => 'Client secret',
    'clients' => 'Clients',
    'documentation' => 'Documentation',
];
